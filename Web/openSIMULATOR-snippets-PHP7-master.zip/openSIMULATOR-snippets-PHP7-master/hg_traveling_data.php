﻿<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>
<?php
  include("./includes/config.php");
  
  $dbort = $CONF_db_server;
  $dbuser = $CONF_db_user;
  $dbpw = $CONF_db_pass;
  $dbdb = $CONF_db_database;

   $con = mysqli_connect($dbort,$dbuser,$dbpw,$dbdb);
   $res = mysqli_query($con, "SELECT * FROM hg_traveling_data");
   
   // Tabellenbeginn
   echo "<table border='2' style='background-color:#C0C0C0;border-collapse:collapse;border:3px solid #FFD800;color:#000000;width:400'>";
   
    // Überschrift
   echo "<tr> <td>Nr.</td>";
   
   echo "<td>SessionID</td>";
   echo "<td>UserID</td>";
   echo "<td>GridExternalName</td>";
   echo "<td>ServiceToken</td>";
   echo "<td>ClientIPAddress</td>";
   echo "<td>MyIPAddress</td>";
   echo "<td>TMStamp</td>";
   
   echo "</tr>";

   $lf = 1;
   while ($dsatz = mysqli_fetch_assoc($res))
   {
      echo "<tr>";
      echo "<td>" . $dsatz["SessionID"] . "</td>";
      echo "<td>" . $dsatz["UserID"] . "</td>";
      echo "<td>" . $dsatz["GridExternalName"] . "</td>";
      echo "<td>" . $dsatz["ServiceToken"] . "</td>";
      echo "<td>" . $dsatz["ClientIPAddress"] . "</td>";
      echo "<td>" . $dsatz["MyIPAddress"] . "</td>";
      echo "<td>" . $dsatz["TMStamp"] . "</td>";
      echo "</tr>";
      $lf = $lf + 1;
   }

   // Tabellenende
   echo "</table>";

   mysqli_close($con);
?>
</body></html>
