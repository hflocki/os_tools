﻿<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>
<?php
  include("./includes/config.php");
  
  $dbort = $CONF_db_server;
  $dbuser = $CONF_db_user;
  $dbpw = $CONF_db_pass;
  $dbdb = $CONF_db_database;

   $con = mysqli_connect($dbort,$dbuser,$dbpw,$dbdb);
   $res = mysqli_query($con, "SELECT * FROM estate_settings");
   
   // Tabellenbeginn
   echo "<table border='2' style='background-color:#C0C0C0;border-collapse:collapse;border:3px solid #FFD800;color:#000000;width:400'>";
   
    // Überschrift
   echo "<tr> <td>Nr.</td>";
   
echo "<td>EstateID</td>";
echo "<td>EstateName</td>";
echo "<td>AbuseEmailToEstateOwner</td>";
echo "<td>DenyAnonymous</td>";
echo "<td>ResetHomeOnTeleport</td>";
echo "<td>FixedSun</td>";
echo "<td>DenyTransacted</td>";
echo "<td>BlockDwell</td>";
echo "<td>DenyIdentified</td>";
echo "<td>AllowVoice</td>";
echo "<td>UseGlobalTime</td>";
echo "<td>PricePerMeter</td>";
echo "<td>TaxFree</td>";
echo "<td>AllowDirectTeleport</td>";
echo "<td>RedirectGridX</td>";
echo "<td>RedirectGridY</td>";
echo "<td>ParentEstateID</td>";
echo "<td>SunPosition</td>";
echo "<td>EstateSkipScripts</td>";
echo "<td>BillableFactor</td>";
echo "<td>PublicAccess</td>";
echo "<td>AbuseEmail</td>";
echo "<td>EstateOwner</td>";
echo "<td>DenyMinors</td>";
echo "<td>AllowLandmark</td>";
echo "<td>AllowParcelChanges</td>";
echo "<td>AllowSetHome</td>";   
   
   echo "</tr>";

   $lf = 1;
   while ($dsatz = mysqli_fetch_assoc($res))
   {
      echo "<tr>";
      echo "<td>$lf</td>";
	  
echo "<td>" . $dsatz["EstateID"] . "</td>";
echo "<td>" . $dsatz["EstateName"] . "</td>";
echo "<td>" . $dsatz["AbuseEmailToEstateOwner"] . "</td>";
echo "<td>" . $dsatz["DenyAnonymous"] . "</td>";
echo "<td>" . $dsatz["ResetHomeOnTeleport"] . "</td>";
echo "<td>" . $dsatz["FixedSun"] . "</td>";
echo "<td>" . $dsatz["DenyTransacted"] . "</td>";
echo "<td>" . $dsatz["BlockDwell"] . "</td>";
echo "<td>" . $dsatz["DenyIdentified"] . "</td>";
echo "<td>" . $dsatz["AllowVoice"] . "</td>";
echo "<td>" . $dsatz["UseGlobalTime"] . "</td>";
echo "<td>" . $dsatz["PricePerMeter"] . "</td>";
echo "<td>" . $dsatz["TaxFree"] . "</td>";
echo "<td>" . $dsatz["AllowDirectTeleport"] . "</td>";
echo "<td>" . $dsatz["RedirectGridX"] . "</td>";
echo "<td>" . $dsatz["RedirectGridY"] . "</td>";
echo "<td>" . $dsatz["ParentEstateID"] . "</td>";
echo "<td>" . $dsatz["SunPosition"] . "</td>";
echo "<td>" . $dsatz["EstateSkipScripts"] . "</td>";
echo "<td>" . $dsatz["BillableFactor"] . "</td>";
echo "<td>" . $dsatz["PublicAccess"] . "</td>";
echo "<td>" . $dsatz["AbuseEmail"] . "</td>";
echo "<td>" . $dsatz["EstateOwner"] . "</td>";
echo "<td>" . $dsatz["DenyMinors"] . "</td>";
echo "<td>" . $dsatz["AllowLandmark"] . "</td>";
echo "<td>" . $dsatz["AllowParcelChanges"] . "</td>";
echo "<td>" . $dsatz["AllowSetHome"] . "</td>";

      echo "</tr>";
      $lf = $lf + 1;
   }

   // Tabellenende
   echo "</table>";

   mysqli_close($con);
?>
</body></html>
