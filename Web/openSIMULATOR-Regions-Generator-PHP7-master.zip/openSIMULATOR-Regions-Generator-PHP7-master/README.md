# openSIMULATOR-Regions-Generator
PHP7 openSIMULATOR Regions Generator V1.11.

Var Kompatibel!

Regions Generator V1.11 ist erstellt für OpenSim 0.9.1

.

Achtung! Diese Software greift schreibend auf ihre Festplatte zu.

Ich schließe jegliche Gewährleistung aus.

Die Nutzung der Software geschieht auf eigenes Risiko.

.

![Title](http://virtual-talk.de/attachment.php?aid=2265)

Der Name der ini ist der Name der Region.

Alle erstellten ini Dateien in das Verzeichnis opensim/bin/Regions kopieren.

Es kann aus den Dateien auch eine Datei gemacht werden.

Es werden nur Regionsdateien mit der Endung ini oder xml vom OpenSimulator geladen.

P.S. Für die Farbanpassung (Einfach w3-blue-grey gegen andere Farbe austauschen) bitte dies hier lesen:

http://www.w3schools.com/w3css/w3css_colors.asp

