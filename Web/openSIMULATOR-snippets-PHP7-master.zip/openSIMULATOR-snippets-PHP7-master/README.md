# OpenSim-PHP-snippets
PHP7 Programmteile und mehr für den OpenSimulator.

.

install.php

Die Installation und Konfiguration für alle Bestandteile hier.

.

GridUserlist.php

Ist eine einfache User liste eures Grid´s.

.

estate_settingslist.php

Zeigt vieles zu den Estate´s an.

.

hg_traveling_data.php

Zeigt einiges an Hypergrid Aktivitäten an.

.

os_groups_groups.php

Zeigt einiges an Gruppeninformationen an.

.

Regionslist.php

Zeigt eine erweiterte Regionsliste an.

.

uuid.clas.php

Ist eine UUID Funktionssammlung.

Wie diese abgefragt wird erklärt die uuid.php

.

weristregistriert.php

ist eine einfache abfrage und ausgabe der Nutzer die Registriert sind.

Dabei werden nur Vorname und Nachname ausgegeben.

.
