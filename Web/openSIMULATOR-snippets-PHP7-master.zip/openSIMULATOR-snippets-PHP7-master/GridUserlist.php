﻿<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>
<?php
  include("./includes/config.php");
  
  $dbort = $CONF_db_server;
  $dbuser = $CONF_db_user;
  $dbpw = $CONF_db_pass;
  $dbdb = $CONF_db_database;

   $con = mysqli_connect($dbort,$dbuser,$dbpw,$dbdb);
   $res = mysqli_query($con, "SELECT * FROM GridUser");
   
   // Tabellenbeginn
   echo "<table border='2' style='background-color:#C0C0C0;border-collapse:collapse;border:3px solid #FFD800;color:#000000;width:400'>";
   
    // Überschrift
   echo "<tr> <td>Nr.</td>";
   
echo "<td>UserID</td>"
echo "<td>HomeRegionID</td>"
echo "<td>HomePosition</td>"
echo "<td>HomeLookAt</td>"
echo "<td>LastRegionID</td>"
echo "<td>LastPosition</td>"
echo "<td>LastLookAt</td>"
echo "<td>Online</td>"
echo "<td>Login</td>"
echo "<td>Logout</td>" 
   
   echo "</tr>";

   $lf = 1;
   while ($dsatz = mysqli_fetch_assoc($res))
   {
      echo "<tr>";
      echo "<td>$lf</td>";
echo "<td>" . $dsatz["UserID"] . "</td>";
echo "<td>" . $dsatz["HomeRegionID"] . "</td>";
echo "<td>" . $dsatz["HomePosition"] . "</td>";
echo "<td>" . $dsatz["HomeLookAt"] . "</td>";
echo "<td>" . $dsatz["LastRegionID"] . "</td>";
echo "<td>" . $dsatz["LastPosition"] . "</td>";
echo "<td>" . $dsatz["LastLookAt"] . "</td>";
echo "<td>" . $dsatz["Online"] . "</td>";
echo "<td>" . $dsatz["Login"] . "</td>";
echo "<td>" . $dsatz["Logout"] . "</td>";
      echo "</tr>";
      $lf = $lf + 1;
   }

   // Tabellenende
   echo "</table>";

   mysqli_close($con);
?>
</body></html>
