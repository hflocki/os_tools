<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>


   
   <!-- iframe hier mit kann der RegionsgeneratorV1_xx in eine bestehende Homepage eingefügt werden.
   
        Zusätzlich kann das ganze noch Skaliert werden damit es gut passt. Dies kann man einstellen in dem man 0.40 verändert (0.40 kleiner, 0.40 größer).
		Beispiel: Einfach suchen ersetzen auswählen und werte eingeben 0.40 nach 0.40
		
        Die Farben stellt man einfach in der Hauptdatei RegionsgeneratorV1_xx.php ein. 	
        w3-blue-grey und w3-text-red brauchen hierfür nur durch suchen und ersetzen geändert werden, siehe hier: http://www.w3schools.com/w3css/w3css_colors.asp
	-->
	
<!-- Anfang -->
<iframe 
frameborder="1" src="./mapmax.php" width="200%" height="260%" style="padding:1px; border:2px solid #000000;
position:absolute; top:5px; left:5px; zoom: 0.40; -moz-transform: scale(0.40); -moz-transform-origin: 0 0; -o-transform: scale(0.40); -o-transform-origin: 0 0; -webkit-transform: scale(0.40); -webkit-transform-origin: 0 0;">
</iframe>
<!-- Ende -->

</body></html>