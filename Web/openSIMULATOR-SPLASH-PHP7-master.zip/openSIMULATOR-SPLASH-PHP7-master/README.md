# OS-SPLASH-PHP7_NEW
Mindestanforderung PHP 5.5 



Achtung! Diese Software greift lesend auf ihre Datenbank zu.

Ich schließe jegliche Gewährleistung aus.

Die Nutzung der Software geschieht auf eigenes Risiko.

.

![Title](http://www.gridtalk.de/attachment.php?aid=2693)


Diese splash/welcome Seite ist alleinstehend und für ein Grid ohne Anmeldemöglichkeit völlig ausreichend.


Die Installation ist recht einfach.

.

    Verzeichnis /includes beschreibbar machen.

    install.php starten und angaben ausfüllen, anschließend Install anklicken.

    index.php aufrufen und testen.

    Das beschreibbar machen des Verzeichnis /includes rückgängig machen.

    install.php löschen.

Fertig!

.


Für weitere Info´s bitte oben in die Wiki schauen.


Viel Spaß wünsche ich euch. 
