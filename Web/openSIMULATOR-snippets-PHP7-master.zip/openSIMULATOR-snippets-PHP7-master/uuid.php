<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>

<!-- UUID Generator für alle möglichen Anwendungen 
     Dies ist eine Demo für die Funktionsabfrage 
	 mit der uuid.clas.php -->

<?php
// Die Funktionen einbinden
include "uuid.clas.php";

// Zufalls UUID ausgeben

// Regions.ini Zeile zusammensetzen
$ausgabe = "RegionUUID = " . $v4uuid;

// UUID aus der Regions.ini.example
echo "Tauschen sie bitte die RegionUUID = 11111111-2222-3333-4444-555555555555 <br>";

// Neue Regions UUID
echo "gegen " . $ausgabe . " aus.<br>";
?>

</body></html>