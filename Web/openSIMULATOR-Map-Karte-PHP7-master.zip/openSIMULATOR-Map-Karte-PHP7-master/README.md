# openSIMULATOR-Map-Karte
Eine Karte mit Installer die auch unter PHP7 funktioniert. (12-2-2017)

Dies ist bereits Bestandteil von openSIMULATOR-SPLASH-PHP7.

Systemanforderungen PHP z.B. unter Windows kann XAMPP genutzt werden. 

Unter Linux einfach Apache und PHP installieren.

.

Achtung! Diese Software greift lesend auf ihrer Datenbank zu.

Ich schließe jegliche Gewährleistung aus.

Die Nutzung der Software geschieht auf eigenes Risiko.

.

1. Verzeichnis /includes beschreibbar machen.

2. install.php starten und angaben ausfüllen, anschließend Install anklicken.

3. map.php aufrufen und testen.

4. Das beschreibbar machen des Verzeichnis /includes rückgängig machen.

5. install.php löschen.

Fertig!

.

![Title](https://github.com/wp2opensim/openSIMULATOR-Map-Karte/blob/master/img/vorschau.jpg)

P.S. Für die Farbanpassung bitte dies hier lesen:

http://www.w3schools.com/w3css/w3css_colors.asp
