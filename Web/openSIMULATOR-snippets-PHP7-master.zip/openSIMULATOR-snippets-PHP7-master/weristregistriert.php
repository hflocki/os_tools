<?php
// weristregistriert ist eine einfache abfrage und ausgabe der Nutzer die Registriert sind.
// Dabei werden nur Vorname und Nachname ausgegeben.

include("./includes/config.php");
	
// Datenbank öffnen
  
$pdo = new PDO("mysql:host=$CONF_db_server;dbname=$CONF_db_database", $CONF_db_user, $CONF_db_pass);

// Avatar Daten auslesen

   $sql = "SELECT FirstName, LastName FROM UserAccounts ORDER BY LastName, FirstName";
   foreach ($pdo->query($sql) as $row) {
   echo $row['FirstName']." ".$row['LastName']." <br />";
}
$pdo = null;
?>