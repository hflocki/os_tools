﻿<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>
<?php
  include("./includes/config.php");
  
  $dbort = $CONF_db_server;
  $dbuser = $CONF_db_user;
  $dbpw = $CONF_db_pass;
  $dbdb = $CONF_db_database;

   $con = mysqli_connect($dbort,$dbuser,$dbpw,$dbdb);
   $res = mysqli_query($con, "SELECT * FROM os_groups_groups");
   
   // Tabellenbeginn
   echo "<table border='5' style='background-color:#C0C0C0;border-collapse:collapse;border:3px solid #FFD800;color:#000000;width:400'>";
   
    // Überschrift
   echo "<tr> <td>Nr.</td>";
   echo "<td>GroupID</td>";
   echo "<td>Location</td>";
   echo "<td>Name</td>";
   echo "<td>Charter</td>";
   echo "<td>InsigniaID</td>";
   echo "<td>FounderID</td>";
   echo "<td>MembershipFee</td>";
   echo "<td>OpenEnrollment</td>";
   echo "<td>ShowInList</td>";
   echo "<td>AllowPublish</td>";
   echo "<td>MaturePublish</td>";
   echo "<td>OwnerRoleID</td>";
   echo "</tr>";

   $lf = 1;
   while ($dsatz = mysqli_fetch_assoc($res))
   {
      echo "<tr>";
      echo "<td>$lf</td>";
      echo "<td>" . $dsatz["td>GroupID"] . "</td>";
      echo "<td>" . $dsatz["td>Location"] . "</td>";
      echo "<td>" . $dsatz["td>Name"] . "</td>";
      echo "<td>" . $dsatz["td>Charter"] . "</td>";
      echo "<td>" . $dsatz["td>InsigniaID"] . "</td>";
      echo "<td>" . $dsatz["td>FounderID"] . "</td>";
      echo "<td>" . $dsatz["td>MembershipFee"] . "</td>";
      echo "<td>" . $dsatz["td>OpenEnrollment"] . "</td>";
      echo "<td>" . $dsatz["td>ShowInList"] . "</td>";
      echo "<td>" . $dsatz["td>AllowPublish"] . "</td>";
      echo "<td>" . $dsatz["td>MaturePublish"] . "</td>";
      echo "<td>" . $dsatz["td>OwnerRoleID"] . "</td>";
      echo "</tr>";
      $lf = $lf + 1;
   }

   // Tabellenende
   echo "</table>";

   mysqli_close($con);
?>
</body></html>
